package com.pravdin.ministere.repositories;

import com.pravdin.ministere.models.Citizen;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CitizenRepository extends JpaRepository<Citizen, Integer> {

    Citizen findByNumAssurSoc(String numAssurSoc);

    Citizen findByNumAssurSocAndFirstNameAndLastNameAndAge(String numAssurSoc, String firstName, String lastName, int age);

    Citizen findByNumAssurSocAndFirstNameAndLastName(String numAssurSoc, String firstName, String lastName);

    Citizen findByNumAssurSocAndFirstNameAndLastNameAndAgeAndNbrDoses(String numAssurSoc, String firstName, String lastName, int age, int nbrDoses);

}
