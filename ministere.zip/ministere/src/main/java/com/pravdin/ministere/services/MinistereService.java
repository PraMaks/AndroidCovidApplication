package com.pravdin.ministere.services;

import com.pravdin.ministere.models.Citizen;
import com.pravdin.ministere.repositories.CitizenRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MinistereService {

    @Autowired
    CitizenRepository citizenRepository;

    public boolean checkIfCitizenExists(String numAssurSoc){
        boolean flag = false;
        try{
            if(citizenRepository.findByNumAssurSoc(numAssurSoc) != null){
                flag = true;
            }
        }
        catch(Exception exception){
            exception.printStackTrace();
        }
        return flag;
    }

    public Citizen findCitizenWithNumAssurSoc(String numAssurSoc){
        Citizen citizen;
        try{
            if(citizenRepository.findByNumAssurSoc(numAssurSoc) != null){
                citizen =  citizenRepository.findByNumAssurSoc(numAssurSoc);
                return citizen;
            }
        }
        catch(Exception exception){
            exception.printStackTrace();
        }
        return null;
    }

    public boolean findIfCitizenIsInfected(String numAssurSoc){
        boolean infection = true;
        try{
            Citizen citizen = findCitizenWithNumAssurSoc(numAssurSoc);
            if(!citizen.isInfectedCovid()){
                return false;
            }
        }
        catch(Exception exception){
            exception.printStackTrace();
        }
        return infection;
    }

    public int findNumberOfDoses(String numAssurSoc){
        int nbrDoses = 0;
        try{
            Citizen citizen = findCitizenWithNumAssurSoc(numAssurSoc);
            nbrDoses = citizen.getNbrDoses();
        }
        catch(Exception exception){
            exception.printStackTrace();
        }
        return nbrDoses;
    }

    public boolean checkIfCitizenExistsFromFrontEnd(String numAssurSoc, String firstName, String lastName, int age, int nbrDoses){
        boolean flag = false;
        try{
            if(citizenRepository.findByNumAssurSocAndFirstNameAndLastNameAndAgeAndNbrDoses(numAssurSoc, firstName, lastName, age, nbrDoses) != null){
                flag = true;
            }
        }
        catch(Exception exception){
            exception.printStackTrace();
        }
        return flag;
    }

    public boolean checkIfCitizenExistsFromFrontEndAndroid(String numAssurSoc, String firstName, String lastName, int age){
        boolean flag = false;
        try{
            if(citizenRepository.findByNumAssurSocAndFirstNameAndLastNameAndAge(numAssurSoc, firstName, lastName, age) != null){
                flag = true;
            }
        }
        catch(Exception exception){
            exception.printStackTrace();
        }
        return flag;
    }
}
