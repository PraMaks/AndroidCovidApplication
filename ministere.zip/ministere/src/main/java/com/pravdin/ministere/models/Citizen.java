package com.pravdin.ministere.models;

import lombok.Data;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

@Data
@Entity
public class Citizen  implements Serializable {

    @Id
    @SequenceGenerator(name = "citizenSeq", sequenceName = "sequencecitizen", initialValue = 1, allocationSize = 100)
    @GeneratedValue(generator = "citizenSeq")
    @Column(name="CITIZEN_ID")
    private Integer citizenId;

    @NotNull
    @Column(name="SOCIAL_NUMBER")
    private String numAssurSoc;

    @NotNull
    @Column(name="FIRST_NAME")
    private String firstName;

    @NotNull
    @Column(name="LAST_NAME")
    private String lastName;

    @NotNull
    @Column(name="GENDER")
    private char sex;

    @NotNull
    @Column(name="AGE")
    private int age;

    @NotNull
    @Column(name="EMAIL")
    private String mail;

    @NotNull
    @Column(name="TELEPHONE_NUMBER")
    private String numTelephone;

    @NotNull
    @Column(name="ADDRESS")
    private String address;

    @NotNull
    @Column(name="CITY")
    private String city;

    @NotNull
    @Column(name="CODE_POSTAL")
    private String postalCode;

    @NotNull
    @Column(name="COVID_INFECTION")
    private boolean infectedCovid;

    @NotNull
    @Column(name="COVID_DOSES")
    private int nbrDoses;

}
