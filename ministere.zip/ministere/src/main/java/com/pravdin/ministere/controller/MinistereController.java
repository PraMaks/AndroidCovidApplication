package com.pravdin.ministere.controller;

import com.pravdin.ministere.services.MinistereService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
//@CrossOrigin(origins = {"http://localhost:8181", "http://localhost:8282"})
public class MinistereController {

    @Autowired
    MinistereService ministereService;

    @GetMapping("/ministere/{numAssurSoc}")
    //http://localhost:8080/ministere/12340987
    public boolean checkIfCitizenExists(@PathVariable String numAssurSoc){
        return ministereService.checkIfCitizenExists(numAssurSoc);
    }

    @GetMapping("/ministere/infected/{numAssurSoc}")
    //http://localhost:8080/ministere/infected/12340987
    public boolean checkIfCitizenIsInfected(@PathVariable String numAssurSoc){
        return ministereService.findIfCitizenIsInfected(numAssurSoc);
    }

    @GetMapping("/ministere/doses/{numAssurSoc}")
    //http://localhost:8080/ministere/doses/123409873
    public int findCitizenDoses(@PathVariable String numAssurSoc){
        return ministereService.findNumberOfDoses(numAssurSoc);
    }

    @GetMapping("/ministere/{age}/{numAssurSoc}/{firstName}+{lastName}/{nbrDoses}")
    //http://localhost:8080/ministere/doses/123409873
    public boolean findCitizenFromFrontEnd(@PathVariable String numAssurSoc, @PathVariable String firstName, @PathVariable String lastName, @PathVariable int age, @PathVariable int nbrDoses){
        if(ministereService.findIfCitizenIsInfected(numAssurSoc)){
            return false;
        }
        return ministereService.checkIfCitizenExistsFromFrontEnd(numAssurSoc, firstName, lastName, age, nbrDoses);
    }

    @GetMapping("/ministere/{age}/{numAssurSoc}/{firstName}+{lastName}")
    //http://localhost:8080/ministere/doses/123409873
    public boolean findCitizenFromFrontEndAndroid(@PathVariable String numAssurSoc, @PathVariable String firstName, @PathVariable String lastName, @PathVariable int age){
        if(ministereService.findIfCitizenIsInfected(numAssurSoc)){
            return false;
        }
        return ministereService.checkIfCitizenExistsFromFrontEndAndroid(numAssurSoc, firstName, lastName, age);
    }
}
