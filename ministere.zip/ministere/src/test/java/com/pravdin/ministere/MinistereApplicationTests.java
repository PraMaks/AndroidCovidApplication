package com.pravdin.ministere;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MinistereApplicationTests {

    @Test
    void contextLoads() {
    }

}
