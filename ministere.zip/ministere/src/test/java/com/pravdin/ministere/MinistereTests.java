package com.pravdin.ministere;

import com.pravdin.ministere.models.Citizen;
import com.pravdin.ministere.repositories.CitizenRepository;
import com.pravdin.ministere.services.MinistereService;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.context.annotation.ComponentScan;

import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@ComponentScan(basePackages = {"com.pravdin.ministere.services"})
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class MinistereTests {
    @Autowired
    private MinistereService services;

    @Autowired
    private CitizenRepository citizenRepository;

    @BeforeAll
    public void insertData() {
        Citizen citizen1 = new Citizen();
        citizen1.setCity("Montreal");
        citizen1.setAddress("rue Java");
        citizen1.setAge(26);
        citizen1.setMail("dev@java.com");
        citizen1.setNumTelephone("514-1234");
        citizen1.setNumAssurSoc("12340987");
        citizen1.setPostalCode("H4E H4E");
        citizen1.setSex('m');
        citizen1.setFirstName("Bernard");
        citizen1.setLastName("Smith");
        citizen1.setInfectedCovid(false);
        citizen1.setNbrDoses(1);
    }

    @Test
    @Order(1)
    @DisplayName("Test de verification de l'existence d'un citoyen")
    public void testCheckIfCitizenExists(){
        assertTrue(services.checkIfCitizenExists("12340987"));
    }

    @Test
    @Order(2)
    @DisplayName("Test de recherche de citoyen")
    public void testFindCitizenWithNumAssurSoc(){
        assertNotNull(services.findCitizenWithNumAssurSoc("12340987"));
    }

    @Test
    @Order(3)
    @DisplayName("Test de verification si le citoyen est infecte")
    public void testCheckIfCitizenIsInfected(){
        assertFalse(services.findIfCitizenIsInfected("12340987"));
    }

    @Test
    @Order(4)
    @DisplayName("Test de recherche du nombre de doses")
    public void testFindNbrDoses(){
        assertEquals(services.findNumberOfDoses("12340987"), 1);
    }
}
